"""Document chatbot application package."""
