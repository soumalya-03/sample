from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "storage" / "Medical_Device_Business_Services_Inc_Mentor_08_09_2026.xlsx"
OUTPUT = ROOT / "data" / "demo_process_kpi_data.xlsx"
DEMO_RESOURCES = [
    {
        "resource_id": "RES-OPS-001",
        "email": "admin@local.dev",
        "name": "Local Admin",
        "persona_id": "role-09",
        "persona_name": "Operations Manager",
        "source_role_sheet": "Role 09 - Operations Mgr",
    },
    {
        "resource_id": "RES-SALES-001",
        "email": "sales@local.dev",
        "name": "Jordan Lee",
        "persona_id": "role-14",
        "persona_name": "Sales Rep",
        "source_role_sheet": "Role 14 - Sales Rep",
    },
]
PROCESSES = [
    ("PROC-ORDER-CAPTURE", "Capture Order", "ACT-CAPTURE", "Capture order request", 1, 90),
    ("PROC-ORDER-VALIDATE", "Validate Order", "ACT-VALIDATE", "Validate customer and order", 2, 120),
    ("PROC-ORDER-SUBMIT", "Submit Order", "ACT-SUBMIT", "Submit validated order", 3, 120),
    ("PROC-DELIVERY", "Delivery", "ACT-DELIVERY", "Confirm delivery status", 4, 180),
]


def clean(value: Any) -> Any:
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat()
    return value


def add_sheet(workbook: Workbook, title: str, headers: list[str], rows: list[list[Any]]) -> None:
    sheet = workbook.create_sheet(title)
    sheet.append(headers)
    for row in rows:
        sheet.append([clean(value) for value in row])
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    for cell in sheet[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="285C4D")
    for column in sheet.columns:
        width = min(max(max(len(str(cell.value or "")) for cell in column) + 2, 12), 38)
        sheet.column_dimensions[column[0].column_letter].width = width


def slug(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")


def extract_kpi_definitions(source_path: Path) -> list[dict[str, Any]]:
    source = load_workbook(source_path, read_only=True, data_only=True)
    definitions: list[dict[str, Any]] = []
    for sheet_name in source.sheetnames:
        match = re.match(r"Role (\d+) - (.+)", sheet_name)
        if not match:
            continue
        role_id = f"role-{int(match.group(1)):02d}"
        role_name = match.group(2)
        for row in source[sheet_name].iter_rows(min_row=10, values_only=True):
            name = row[0] if len(row) > 0 else None
            formula = row[1] if len(row) > 1 else None
            if isinstance(name, str) and name.startswith("SIX-PHASE"):
                break
            if not isinstance(name, str) or not isinstance(formula, str) or not formula.strip():
                continue
            metric_id = f"{role_id}-{slug(name)}"
            lower_name = name.lower()
            if "handle time" in lower_name or "resolution time" in lower_name:
                unit, aggregation = "minutes", "average"
            elif "satisfaction" in lower_name or "csat" in lower_name or "quality score" in lower_name:
                unit, aggregation = "score", "average"
            elif "calls handled" in lower_name:
                unit, aggregation = "calls", "count"
            else:
                unit, aggregation = "%", "ratio_percent"
            definitions.append(
                {
                    "kpi_id": metric_id,
                    "name": name,
                    "description": formula,
                    "role_id": role_id,
                    "role_name": role_name,
                    "unit": unit,
                    "aggregation": aggregation,
                    "source": f"{SOURCE.name} | {sheet_name}",
                    "illustrative": True,
                }
            )
    source.close()
    return definitions


def main() -> None:
    if not SOURCE.exists():
        raise FileNotFoundError(f"Source business workbook not found: {SOURCE}")

    definitions = extract_kpi_definitions(SOURCE)
    definition_by_id = {item["kpi_id"]: item for item in definitions}
    base_time = datetime(2026, 10, 1, 12, 0, tzinfo=timezone.utc)
    request_rows: list[list[Any]] = []
    execution_rows: list[list[Any]] = []
    measurement_rows: list[list[Any]] = []
    alert_rows: list[list[Any]] = []
    outcome_rows: list[list[Any]] = []

    for resource in DEMO_RESOURCES:
        for request_number in range(1, 7):
            request_id = f"REQ-{resource['resource_id'].split('-')[1]}-{request_number:03d}"
            created_at = base_time - timedelta(days=3 * request_number + (0 if resource["persona_id"] == "role-09" else 1))
            request_status = "Completed" if request_number in {1, 3, 5, 6} else "In Progress"
            if request_number == 4:
                request_status = "Overdue"
            request_rows.append(
                [request_id, f"SYN-CUSTOMER-{request_number:03d}", created_at, request_status,
                 resource["resource_id"], resource["persona_id"], "DEMO/SYNTHETIC", "Order-to-Delivery"]
            )

            for process_index, process in enumerate(PROCESSES):
                process_id, process_name, activity_id, task_name, sequence, sla_minutes = process
                execution_id = f"EXE-{request_id}-{sequence}"
                start_at = created_at + timedelta(minutes=sequence * 18 + request_number * 3)
                status = "Completed"
                duration = 32 + ((request_number * 13 + sequence * 17) % 100)
                failure_reason = None
                retry_count = 0
                ended_at: datetime | None = start_at + timedelta(minutes=duration)
                if request_number == 2 and sequence == 4:
                    status, ended_at, duration = "In Progress", None, None
                elif request_number == 4 and sequence == 3:
                    status, ended_at, duration = "In Progress", None, None
                    start_at = base_time - timedelta(hours=8)
                elif request_number == 3 and sequence == 2:
                    status, failure_reason = "Failed", "Synthetic validation failure for retry demonstration"
                    ended_at = start_at + timedelta(minutes=duration)
                    retry_count = 0
                elif request_number == 3 and sequence == 3:
                    retry_count = 1

                predecessor = PROCESSES[sequence - 2][0] if sequence > 1 else None
                successor = PROCESSES[sequence][0] if sequence < len(PROCESSES) else None
                execution_rows.append(
                    [
                        f"TX-{request_id}", request_id, None, execution_id, process_id,
                        predecessor, successor, f"ACT-{sequence:02d}", f"TASK-{sequence:02d}",
                        f"WF-{request_id}", sequence, f"CORR-{request_id}", process_name,
                        f"{process_name} activity", task_name, status, status, request_status,
                        "Failed" if status == "Failed" else ("In Progress" if status == "In Progress" else "Completed"),
                        failure_reason, retry_count, "FUNCTION-OPERATIONS", resource["persona_id"],
                        resource["resource_id"], resource["email"], start_at - timedelta(minutes=12),
                        start_at - timedelta(minutes=7), start_at, created_at, start_at, start_at,
                        ended_at, duration, 7, 12, sla_minutes, sla_minutes, None, None,
                        "DEMO/SYNTHETIC", failure_reason, created_at.date().isoformat(),
                    ]
                )
                observed_minutes = duration if duration is not None else (base_time - start_at).total_seconds() / 60
                if observed_minutes > sla_minutes:
                    alert_id = f"ALT-{execution_id}"
                    alert_rows.append(
                        [alert_id, execution_id, request_id, process_id, resource["persona_id"],
                         resource["resource_id"], "SLA breach", "High", observed_minutes, sla_minutes,
                         "Open", base_time, "Synthetic elapsed time exceeded configured SLA"]
                    )
                    execution_rows[-1][-2] = alert_id
                    execution_rows[-1][-1] = "High"
                if request_number == 3 and sequence == 2:
                    retry = list(execution_rows[-1])
                    retry[3] = f"{retry[3]}-R1"
                    retry[15] = retry[16] = retry[17] = "Completed"
                    retry[18] = "Completed"
                    retry[19] = None
                    retry[20] = 1
                    retry_start = retry[31] + timedelta(minutes=5)
                    retry_end = retry_start + timedelta(minutes=max(25, int(duration) - 20))
                    retry[27] = retry_start
                    retry[30] = retry_start
                    retry[31] = retry_end
                    retry[32] = (retry_end - retry_start).total_seconds() / 60
                    retry[33] = 5
                    retry[34] = 5
                    retry[-2:] = [None, None]
                    execution_rows.append(retry)

            outcome_rows.append(
                [f"OUT-{request_id}", request_id, "Order delivery" if request_status == "Completed" else "Order fulfillment in progress",
                 "Synthetic outcome; no real customer data", "DEMO/SYNTHETIC"]
            )

        role_definitions = [item for item in definitions if item["role_id"] == resource["persona_id"]]
        for definition in role_definitions:
            seed = sum(ord(char) for char in resource["email"] + definition["kpi_id"])
            for period_index in range(4):
                period_end = base_time.date() - timedelta(weeks=3 - period_index)
                if definition["aggregation"] == "average":
                    value = round(4.0 + (seed + period_index * 7) % 10 / 10, 2) if definition["unit"] == "score" else round(38 + (seed + period_index * 11) % 24, 2)
                    numerator, denominator = value * 10, 10
                elif definition["aggregation"] == "count":
                    numerator, denominator = 35 + (seed + period_index * 13) % 30, None
                else:
                    denominator = 100
                    numerator = 82 + (seed + period_index * 9) % 18
                measurement_rows.append(
                    [f"MEAS-{definition['kpi_id']}-{period_index + 1}", definition["kpi_id"],
                     resource["email"], period_end - timedelta(days=6), period_end,
                     numerator, denominator, definition["unit"], 100 if denominator else int(numerator),
                     "DEMO/SYNTHETIC", True]
                )

    # Additional process metrics are derived at runtime from execution records.
    for metric_id, name, formula, unit in [
        ("process-completion-rate", "Process Completion Rate", "Completed executions ÷ Started executions × 100", "%"),
        ("average-process-duration", "Average Completed Process Duration", "Mean duration of completed executions; unfinished executions excluded", "minutes"),
        ("on-time-completion-rate", "On-Time Completion Rate", "Completed executions within configured SLA ÷ Completed executions × 100", "%"),
    ]:
        definitions.append({"kpi_id": metric_id, "name": name, "description": formula,
                           "role_id": "all", "role_name": "All assigned demo roles", "unit": unit,
                           "aggregation": "derived_from_executions", "source": "Synthetic process executions",
                           "illustrative": True})

    workbook = Workbook()
    workbook.remove(workbook.active)
    add_sheet(workbook, "Customer_Requests",
              ["request_id", "synthetic_customer_ref", "request_created_at", "request_status", "owner_resource_id", "owner_persona_id", "data_source_type", "value_stream"], request_rows)
    add_sheet(workbook, "Process_Master",
              ["process_id", "process_name", "process_sequence", "predecessor_process_id", "successor_process_id", "is_start", "is_end", "sla_target_minutes", "source", "data_source_type"],
              [[p[0], p[1], p[4], PROCESSES[i - 1][0] if i else None, PROCESSES[i + 1][0] if i < len(PROCESSES) - 1 else None, i == 0, i == len(PROCESSES) - 1, p[5], f"{SOURCE.name} | Consulting Flows", "DEMO/SYNTHETIC workflow"] for i, p in enumerate(PROCESSES)])
    add_sheet(workbook, "Activities_Tasks",
              ["activity_id", "activity_name", "task_id", "task_name", "process_id", "persona_id", "function_id"],
              [[f"ACT-{i:02d}", p[1] + " activity", f"TASK-{i:02d}", p[3], p[0], "assigned per execution", "FUNCTION-OPERATIONS"] for i, p in enumerate(PROCESSES, 1)])
    add_sheet(workbook, "Persona_Resource_Mapping",
              ["resource_id", "email", "display_name", "persona_id", "persona_name", "source_role_sheet", "data_source_type"],
              [[r["resource_id"], r["email"], r["name"], r["persona_id"], r["persona_name"], r["source_role_sheet"], "DEMO/SYNTHETIC assignment"] for r in DEMO_RESOURCES])
    add_sheet(workbook, "Workflow_Definitions",
              ["workflow_id", "sequence", "process_id", "predecessor_process_id", "successor_process_id", "transition_condition", "is_start", "is_end"],
              [["WF-ORDER-DELIVERY", p[4], p[0], PROCESSES[i - 1][0] if i else None, PROCESSES[i + 1][0] if i < len(PROCESSES) - 1 else None, "Always; illustrative demo flow", i == 0, i == len(PROCESSES) - 1] for i, p in enumerate(PROCESSES)])
    execution_headers = ["transaction_id", "customer_request_id", "parent_transaction_id", "process_execution_id", "process_id", "predecessor_process_id", "successor_process_id", "activity_id", "task_id", "workflow_instance_id", "process_sequence", "correlation_id", "process_name", "activity_name", "task_name", "process_execution_status", "task_status", "workflow_status", "execution_outcome", "failure_reason", "retry_count", "function_id", "persona_id", "assigned_resource_id", "assigned_resource_email", "assignment_timestamp", "queue_entry_timestamp", "queue_exit_timestamp", "request_created_timestamp", "process_created_timestamp", "process_start_timestamp", "process_end_timestamp", "actual_duration_minutes", "queue_wait_minutes", "assignment_to_start_minutes", "expected_process_duration_minutes", "sla_target_duration_minutes", "historical_average_minutes", "lower_control_limit_minutes", "upper_control_limit_minutes", "data_source_type", "recorded_delay_reason", "business_date"]
    # Alert metadata is kept in Alert_History; add its reference columns to the execution ledger.
    execution_headers.extend(["alert_id", "alert_severity"])
    add_sheet(workbook, "Process_Executions", execution_headers, execution_rows)
    add_sheet(workbook, "KPI_Definitions",
              ["kpi_id", "kpi_name", "description", "persona_id", "persona_name", "measurement_unit", "aggregation_method", "target_value", "measurement_period", "source", "data_source_type", "illustrative"],
              [[d["kpi_id"], d["name"], d["description"], d["role_id"], d["role_name"], d["unit"], d["aggregation"], None, "Weekly", d["source"], "DEMO/SYNTHETIC measurements" if d["illustrative"] else "Reference definition", d["illustrative"]] for d in definitions])
    add_sheet(workbook, "KPI_Measurements",
              ["measurement_id", "kpi_id", "resource_email", "period_start", "period_end", "numerator", "denominator", "unit", "sample_size", "data_source_type", "synthetic"], measurement_rows)
    add_sheet(workbook, "Alert_Rules",
              ["rule_id", "process_id", "rule_type", "sla_target_minutes", "control_limit_method", "control_limit_status", "source"],
              [[f"SLA-{p[0]}", p[0], "SLA", p[5], None, "Not configured; insufficient historical samples for statistical limits", "Illustrative demo SLA; not a J&J-approved target"] for p in PROCESSES])
    add_sheet(workbook, "Alert_History",
              ["alert_id", "process_execution_id", "customer_request_id", "process_id", "persona_id", "resource_id", "alert_type", "severity", "observed_minutes", "threshold_minutes", "resolution_status", "detected_at", "reason"], alert_rows)
    add_sheet(workbook, "Business_Outcomes",
              ["outcome_id", "customer_request_id", "outcome_name", "description", "data_source_type"], outcome_rows)
    dictionary_rows = [
        ["Customer_Requests.request_id", "string", "Required", "Stable synthetic request identifier"],
        ["Customer_Requests.synthetic_customer_ref", "string", "Required", "Non-identifying synthetic customer reference; not a real person"],
        ["Process_Executions.process_execution_id", "string", "Required", "Unique process execution attempt; retries create separate rows"],
        ["Process_Executions.process_start_timestamp", "UTC ISO-8601", "Required", "Process start time"],
        ["Process_Executions.process_end_timestamp", "UTC ISO-8601/null", "Optional", "Null while unfinished; do not treat as completed duration"],
        ["Process_Executions.actual_duration_minutes", "number/null", "Optional", "Recorded only for completed or failed attempts"],
        ["Process_Executions.sla_target_duration_minutes", "number", "Required", "Illustrative SLA threshold; distinct from statistical control limits"],
        ["Process_Executions.lower_control_limit_minutes", "number/null", "Optional", "Not populated: insufficient historical samples"],
        ["Process_Executions.upper_control_limit_minutes", "number/null", "Optional", "Not populated: insufficient historical samples"],
        ["KPI_Definitions.source", "string", "Required", "Workbook/tab lineage for the KPI name and formula"],
        ["KPI_Definitions.illustrative", "boolean", "Required", "True means no approved target/production observation was supplied"],
        ["KPI_Measurements.numerator/denominator", "number", "Required where applicable", "Synthetic weekly inputs; API computes displayed ratios"],
        ["KPI_Measurements.resource_email", "string", "Required", "Demo account scope; never use the editable frontend selection as authorization"],
    ]
    documented_fields = {row[0] for row in dictionary_rows}
    for sheet in workbook.worksheets:
        for cell in sheet[1]:
            field_name = f"{sheet.title}.{cell.value}"
            if field_name in documented_fields:
                continue
            field = str(cell.value).lower()
            if field.endswith("_id") or field.endswith("_email"):
                data_type, meaning = "string", "Stable identifier or reference; see related worksheet for its parent record"
            elif "timestamp" in field or field.endswith("_at") or field.endswith("_date"):
                data_type, meaning = "UTC ISO-8601", "Timestamp/date for this demo record"
            elif "duration" in field or "minutes" in field or field in {"numerator", "denominator", "sample_size", "process_sequence", "retry_count"}:
                data_type, meaning = "number/null", "Synthetic numeric input or calculated duration; null when not yet available"
            elif field in {"is_start", "is_end", "synthetic", "illustrative"}:
                data_type, meaning = "boolean", "Flag describing this synthetic demo record or workflow definition"
            else:
                data_type, meaning = "string", "Synthetic demo attribute; values are illustrative and not production observations"
            dictionary_rows.append([field_name, data_type, "Required unless null", meaning])
            documented_fields.add(field_name)
    add_sheet(workbook, "Data_Dictionary", ["field", "data_type", "required", "meaning_or_relationship"], dictionary_rows)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(OUTPUT)
    print(f"Created {OUTPUT} with {len(definitions)} KPI definitions, {len(measurement_rows)} synthetic measurements, {len(execution_rows)} process executions, and {len(alert_rows)} SLA alerts.")


if __name__ == "__main__":
    main()
