from __future__ import annotations

from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.orm import Session

from backend.app.db.database import get_db
from backend.app.db.models import User
from backend.app.services.auth_service import decode_access_token
from backend.app.services.demo_dashboard_service import (
    DEMO_ACCOUNT_ASSIGNMENTS,
    build_individual_dashboard_payload,
)

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/persona")
def get_dashboard_for_persona(
    authorization: str = Header(default=""),
    db: Session = Depends(get_db),
) -> dict:
    scheme, _, token = authorization.partition(" ")
    claims = decode_access_token(token) if scheme.lower() == "bearer" else None
    if not claims:
        raise HTTPException(status_code=401, detail="Sign in to view this dashboard")
    user = db.get(User, claims.get("sub"))
    if user is None or user.email != claims.get("email"):
        raise HTTPException(status_code=401, detail="Sign in to view this dashboard")
    assignment = DEMO_ACCOUNT_ASSIGNMENTS.get(user.email)
    if assignment is None or claims.get("role") != assignment["role"]:
        raise HTTPException(status_code=403, detail="No dashboard is assigned to this user")
    try:
        return build_individual_dashboard_payload(
            user.email,
            {"name": user.name, "email": user.email},
            assignment["persona_id"],
        )
    except FileNotFoundError as error:
        raise HTTPException(status_code=503, detail="The demo KPI workbook is unavailable") from error
