# Enterprise Document Chatbot

A production-minded RAG application for local and cloud document QA, with FastAPI backend, React + Vite frontend, Chroma vector storage, LangChain/LangGraph orchestration, and SQLite persistence.

## Architecture

- Frontend: React + TypeScript + Vite + Tailwind
- Backend: FastAPI + SQLAlchemy + Pydantic + LangChain + LangGraph
- Storage: SQLite + local file storage + ChromaDB persistent collections
- Models: local Ollama default, optional Groq or provider adapters

## Local setup

1. Create and activate a Python environment:
   - `py -m venv .venv`
   - `.venv\Scripts\Activate.ps1`
2. Install backend dependencies:
   - `py -m pip install -r backend/requirements.txt`
3. Copy environment file:
   - `Copy-Item .env.example .env`
4. Update `.env` for your local model configuration.
5. Initialize the database:
   - `py -m backend.app.main` or call the app bootstrap in the backend service.
6. Install Node.js LTS and build the frontend:
   - `Set-Location frontend`
   - `npm install`
   - `npm run build`
   - `Set-Location ..`
7. Start the app:
   - `py -m uvicorn backend.app.main:app --reload --host 127.0.0.1 --port 8000`

## Required local models

For the default local mode, install Ollama and pull models such as:

- `ollama pull llama3.1`
- `ollama pull nomic-embed-text`

The app will fail gracefully when these are unavailable and will show startup health warnings.

## Deployment

See Docker Compose and Dockerfiles in the repository root and backend/frontend folders.

## Environment variables

The main settings are in `.env.example`.

## Smoke tests

- Upload a supported document.
- Confirm the document enters `processed` state.
- Ask a question grounded in a document.
- Confirm citations include filename and excerpt.
- Verify cross-user isolation in multi-user mode.

## Notes

This project defaults to a safe local-first mode. Paid providers are optional and never activated automatically.

## KPI dashboard status

For a complete architecture, data, login, dashboard, and manager Q&A walkthrough, see [DASHBOARD_EXPLANATION_GUIDE.md](DASHBOARD_EXPLANATION_GUIDE.md).

The existing FastAPI + React application now reads its individual demo scorecards and process history from `data/demo_process_kpi_data.xlsx`. KPI names and formulas are extracted from the role-specific sheets in `storage/Medical_Device_Business_Services_Inc_Mentor_08_09_2026.xlsx`; process executions, weekly measurements, and SLA alerts are synthetic examples. They are explicitly labeled `DEMO / SYNTHETIC DATA` and are not approved business results.

The dashboard includes account-scoped role KPIs, weekly trends, a searchable process execution ledger, in-progress elapsed time, a separate retry attempt, and traceable SLA alerts. Incomplete executions have no actual duration. Control limits are not populated because the workbook does not provide enough validated historical observations. Synthetic KPI targets are not inferred from the source workbook.

Regenerate the demo data after changing the source workbook with:

```powershell
py backend/scripts/generate_demo_process_kpi_data.py
```

The generated workbook separates customer requests, process master/workflow definitions, activities/tasks, demo persona/resource assignments, process executions, KPI definitions/measurements, alert rules/history, business outcomes, and a field-level data dictionary.

The seeded demo account assignments are enforced by the backend: `admin@local.dev` / `local-dev` uses Role 09 – Operations Manager; `sales@local.dev` / `local-sales` uses Role 14 – Sales Rep. Selecting a different persona for those accounts is rejected. Other configured persona options remain on the landing page, but no demo accounts are assigned to them. Category-to-persona authorization is still not defined. Google/Microsoft OAuth and email OTP are not configured.

## Login personas

- Role 01 – CC Customer
- Role 02 – CC Inventory
- Role 03 – CC Warranty
- Role 04 – BO Customer
- Role 05 – BO Inventory
- Role 06 – BO Warranty
- Role 07 – CC Manager
- Role 08 – BO Manager
- Role 09 – Operations Manager
- Role 10 – Quality Analyst
- Role 11 – Admin Executive
- Role 12 – Surgeon
- Role 13 – Office Manager
- Role 14 – Sales Rep
- Role 15 – CEO
- Role 16 – Patient
- Role 17 – Manager

The 17 existing frontend persona options are preserved. The supplied KPI workbook contains 16 role tabs and differs from the current frontend list for some role names; no unsupported role mapping is inferred. Only the two assignments documented above are active in the demo.

## Run the dashboard

Install frontend dependencies, build the React app, and start FastAPI:

```powershell
Set-Location frontend
npm install
npm run build
Set-Location ..
py -m uvicorn backend.app.main:app --reload --host 127.0.0.1 --port 8000
```

Open `http://localhost:8000/`. For live frontend development, use `npm run dev` from `frontend` in one terminal and start FastAPI in another; open `http://localhost:5173/`. If no build exists in development, FastAPI redirects `/` to Vite.

Demo credentials: `admin@local.dev` / `local-dev` and `sales@local.dev` / `local-sales`.

All observations in the generated workbook are synthetic. Production process tracking, persistent assignment history, validated SLA targets/control-limit rules, category authorization, remaining persona assignments, and OAuth/email OTP require separate integration work.
