from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

from backend.app.config import ROOT_DIR


DEMO_WORKBOOK_PATH = ROOT_DIR / "data" / "demo_process_kpi_data.xlsx"
DEMO_ACCOUNT_ASSIGNMENTS = {
    "admin@local.dev": {
        "role": "operations",
        "persona_id": "role-09",
        "designation": "Role 09 - Operations Manager",
    },
    "sales@local.dev": {
        "role": "sales",
        "persona_id": "role-14",
        "designation": "Role 14 - Sales Rep",
    },
}


def _read_table(workbook, sheet_name: str) -> list[dict[str, Any]]:
    sheet = workbook[sheet_name]
    rows = sheet.iter_rows(values_only=True)
    headers = next(rows)
    return [
        dict(zip(headers, row))
        for row in rows
        if any(value is not None for value in row)
    ]


def _number(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _measurement_value(measurement: dict[str, Any], definition: dict[str, Any]) -> float:
    aggregation = definition["aggregation_method"]
    numerator = _number(measurement.get("numerator"))
    denominator = _number(measurement.get("denominator"))
    if aggregation == "ratio_percent":
        return round(numerator / denominator * 100, 2) if denominator else 0.0
    if aggregation == "average":
        return round(numerator / denominator, 2) if denominator else 0.0
    return round(numerator, 2)


def _format_execution(row: dict[str, Any], now: datetime) -> dict[str, Any]:
    started = datetime.fromisoformat(row["process_start_timestamp"])
    ended = datetime.fromisoformat(row["process_end_timestamp"]) if row.get("process_end_timestamp") else None
    elapsed = round(((ended or now) - started).total_seconds() / 60, 1)
    return {
        "process_execution_id": row["process_execution_id"],
        "customer_request_id": row["customer_request_id"],
        "process_id": row["process_id"],
        "process_name": row["process_name"],
        "activity_name": row["activity_name"],
        "task_name": row["task_name"],
        "process_sequence": int(row["process_sequence"]),
        "status": row["process_execution_status"],
        "outcome": row["execution_outcome"],
        "persona_id": row["persona_id"],
        "resource_id": row["assigned_resource_id"],
        "started_at": row["process_start_timestamp"],
        "ended_at": row.get("process_end_timestamp"),
        "duration_minutes": _number(row.get("actual_duration_minutes")) if row.get("actual_duration_minutes") is not None else None,
        "elapsed_minutes": elapsed if ended is None else None,
        "sla_target_minutes": _number(row.get("sla_target_duration_minutes")),
        "retry_count": int(row.get("retry_count") or 0),
        "failure_reason": row.get("failure_reason"),
        "alert_id": row.get("alert_id"),
    }


def build_individual_dashboard_payload(
    email: str,
    viewer: dict[str, str],
    persona_id: str,
    workbook_path: Path = DEMO_WORKBOOK_PATH,
) -> dict[str, Any]:
    if not workbook_path.exists():
        raise FileNotFoundError(f"Demo KPI workbook not found: {workbook_path}")

    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    try:
        definitions = _read_table(workbook, "KPI_Definitions")
        measurements = _read_table(workbook, "KPI_Measurements")
        all_executions = _read_table(workbook, "Process_Executions")
        alerts = _read_table(workbook, "Alert_History")
        requests = _read_table(workbook, "Customer_Requests")
    finally:
        workbook.close()

    normalized_email = email.strip().lower()
    executions = [
        row for row in all_executions
        if str(row.get("assigned_resource_email", "")).lower() == normalized_email
    ]
    definitions_by_id = {row["kpi_id"]: row for row in definitions}
    measurements_by_id: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in measurements:
        if str(row.get("resource_email", "")).lower() == normalized_email:
            measurements_by_id[row["kpi_id"]].append(row)

    kpis: list[dict[str, Any]] = []
    for definition in definitions:
        role_id = definition["persona_id"]
        if role_id not in {persona_id, "all"}:
            continue
        metric_id = definition["kpi_id"]
        if definition["aggregation_method"] == "derived_from_executions":
            relevant = executions
            completed = [row for row in relevant if row["process_execution_status"] == "Completed"]
            if metric_id == "process-completion-rate":
                denominator = len(relevant)
                value = round(len(completed) / denominator * 100, 2) if denominator else 0.0
            elif metric_id == "average-process-duration":
                durations = [_number(row["actual_duration_minutes"]) for row in completed if row.get("actual_duration_minutes") is not None]
                value = round(sum(durations) / len(durations), 2) if durations else 0.0
            else:
                denominator = len(completed)
                on_time = [
                    row for row in completed
                    if _number(row.get("actual_duration_minutes")) <= _number(row.get("sla_target_duration_minutes"))
                ]
                value = round(len(on_time) / denominator * 100, 2) if denominator else 0.0
            kpis.append({
                "id": metric_id,
                "name": definition["kpi_name"],
                "description": definition["description"],
                "value": value,
                "unit": definition["measurement_unit"],
                "period": "All demo executions",
                "status": "DEMO / illustrative",
                "source": definition["source"],
                "sample_size": len(completed) if metric_id == "average-process-duration" else len(relevant),
                "series": [],
            })
            continue

        points = sorted(measurements_by_id.get(metric_id, []), key=lambda row: row["period_end"])
        if not points:
            continue
        series = [
            {
                "time": str(point["period_end"])[:10],
                "value": _measurement_value(point, definition),
            }
            for point in points
        ]
        latest = points[-1]
        kpis.append({
            "id": metric_id,
            "name": definition["kpi_name"],
            "description": definition["description"],
            "value": series[-1]["value"],
            "unit": definition["measurement_unit"],
            "period": "Weekly",
            "status": "DEMO / illustrative",
            "source": definition["source"],
            "sample_size": int(latest.get("sample_size") or 0),
            "series": series,
        })

    now = datetime.now(timezone.utc)
    formatted_executions = [_format_execution(row, now) for row in executions]
    formatted_executions.sort(key=lambda row: (row["started_at"], row["process_sequence"]))
    scoped_request_ids = {row["customer_request_id"] for row in executions}
    scoped_requests = [row for row in requests if row["request_id"] in scoped_request_ids]
    scoped_alerts = [row for row in alerts if row["customer_request_id"] in scoped_request_ids]
    completed = [row for row in executions if row["process_execution_status"] == "Completed"]
    active = [row for row in executions if row["process_execution_status"] == "In Progress"]
    overdue_request_count = sum(1 for row in scoped_requests if row["request_status"] == "Overdue")
    latest_by_request: dict[str, dict[str, Any]] = {}
    for row in formatted_executions:
        previous = latest_by_request.get(row["customer_request_id"])
        if previous is None or row["process_sequence"] >= previous["process_sequence"]:
            latest_by_request[row["customer_request_id"]] = row

    return {
        "persona": persona_id,
        "viewer": {**viewer, "designation": next((row["persona_name"] for row in _read_persona_rows() if row["persona_id"] == persona_id), persona_id)},
        "data_source": "DEMO / SYNTHETIC DATA",
        "updated_at": int(now.timestamp() * 1000),
        "status_panel": {
            "title": "My process performance",
            "summary": "Illustrative records scoped to this authenticated demo account.",
            "items": [
                {"label": "Customer requests", "value": len(scoped_requests)},
                {"label": "Processes in progress", "value": len(active)},
                {"label": "Completed processes", "value": len(completed)},
                {"label": "Overdue requests", "value": overdue_request_count},
                {"label": "Open alerts", "value": sum(1 for row in scoped_alerts if row["resolution_status"] == "Open")},
            ],
        },
        "metric_panel": {
            "title": "Individual KPI scorecard",
            "items": [
                {"label": item["name"], "value": item["value"], "unit": item["unit"], "status": item["status"]}
                for item in kpis
            ],
        },
        "responsibility_panel": {"title": "Assigned work", "items": []},
        "action_panel": {"title": "Investigation candidates", "items": []},
        "workflow_panel": {
            "title": "Latest request workflow",
            "items": [
                {"step": row["process_name"], "status": row["status"]}
                for row in sorted(latest_by_request.values(), key=lambda item: item["started_at"])[-4:]
            ],
        },
        "kpis": kpis,
        "requests": scoped_requests,
        "process_executions": formatted_executions,
        "alerts": scoped_alerts,
    }


def _read_persona_rows() -> list[dict[str, Any]]:
    if not DEMO_WORKBOOK_PATH.exists():
        return []
    workbook = load_workbook(DEMO_WORKBOOK_PATH, read_only=True, data_only=True)
    try:
        return _read_table(workbook, "Persona_Resource_Mapping")
    finally:
        workbook.close()
