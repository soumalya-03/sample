import { useEffect, useMemo, useState } from 'react';
import { CATEGORIES, PERSONAS } from './config/loginOptions';

type User = {
  user_id?: number;
  email: string;
  name: string;
  role?: string;
  persona_id?: string;
  designation?: string;
  access_token: string;
};

type Kpi = {
  id: string;
  name: string;
  value: number;
  target?: number;
  unit?: string;
  status?: string;
  description?: string;
  category?: string;
  period?: string;
  source?: string;
  sample_size?: number;
  series?: { time: string; value: number }[];
};

type ProcessExecution = {
  process_execution_id: string;
  customer_request_id: string;
  process_name: string;
  activity_name: string;
  task_name: string;
  process_sequence: number;
  status: string;
  started_at: string;
  duration_minutes: number | null;
  elapsed_minutes: number | null;
  sla_target_minutes: number;
  retry_count: number;
  failure_reason: string | null;
  alert_id: string | null;
};

type DashboardAlert = {
  alert_id: string;
  process_execution_id: string;
  customer_request_id: string;
  alert_type: string;
  severity: string;
  observed_minutes: number;
  threshold_minutes: number;
  resolution_status: string;
  detected_at: string;
  reason: string;
};

type DashboardView = 'overview' | 'metrics' | 'alerts' | 'workflows';

type DashboardResponse = {
  persona: string;
  viewer: { name: string; email: string; designation?: string };
  updated_at: number;
  data_source?: string;
  status_panel?: { title: string; summary: string; items: { label: string; value: string | number }[] };
  metric_panel?: { title: string; items: { label: string; value: number | string; unit?: string; status?: string }[] };
  responsibility_panel?: { title: string; items: { title: string; owner: string; due: string; status: string }[] };
  action_panel?: { title: string; items: { title: string; priority: string; kpi: string }[] };
  workflow_panel?: { title: string; items: { step: string; status: string }[] };
  kpis?: Kpi[];
  process_executions?: ProcessExecution[];
  alerts?: DashboardAlert[];
  personas?: string[];
};

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? (window.location.port === '5173' ? 'http://localhost:8000' : window.location.origin);
const STORAGE_KEY = 'jj-dashboard-user';

async function apiFetch<T>(url: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE}${url}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers ?? {}),
    },
    ...options,
  });

  if (!response.ok) {
    const message = await response.text();
    let detail = message;
    try {
      detail = JSON.parse(message).detail || message;
    } catch { /* Non-JSON error responses use their text body. */ }
    throw new Error(detail || 'Request failed');
  }

  return response.json() as Promise<T>;
}

function TrendChart({ kpi }: { kpi: Kpi }) {
  const values = kpi.series ?? [];
  if (values.length < 2) return null;
  const minimum = Math.min(...values.map((point) => point.value));
  const maximum = Math.max(...values.map((point) => point.value));
  const range = maximum - minimum || 1;
  const points = values.map((point, index) => ({
    x: (index / (values.length - 1)) * 100,
    y: 84 - ((point.value - minimum) / range) * 66,
  }));
  const line = points.map((point) => `${point.x},${point.y}`).join(' ');
  const area = `0,100 ${line} 100,100`;

  return (
    <div className="trend-chart-wrap">
      <svg className="trend-chart" viewBox="0 0 100 100" preserveAspectRatio="none" role="img" aria-label={`${kpi.name} trend for ${kpi.period ?? 'the selected period'}`}>
        <polygon className="trend-area" points={area} />
        <polyline className="trend-line" points={line} />
        <circle className="trend-point" cx={points[points.length - 1].x} cy={points[points.length - 1].y} r="2.4" />
      </svg>
      <div className="trend-range"><span>{values[0].time}</span><span>{values[values.length - 1].time}</span></div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      const parsed = saved ? JSON.parse(saved) as User : null;
      if (parsed?.access_token) return parsed;
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      localStorage.removeItem(STORAGE_KEY);
    }
    return null;
  });
  const [category, setCategory] = useState('');
  const [persona, setPersona] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [dashboard, setDashboard] = useState<DashboardResponse | null>(null);
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [processSearch, setProcessSearch] = useState('');
  const [activeView, setActiveView] = useState<DashboardView>('overview');

  useEffect(() => {
    if (!user) return;
    void fetchDashboard(user, true);
  }, [user]);

  const fetchDashboard = async (activeUser: User, showLoading = false) => {
    try {
      if (showLoading) setDashboardLoading(true);
      const payload = await apiFetch<DashboardResponse>('/api/dashboard/persona', {
        headers: { Authorization: `Bearer ${activeUser.access_token}` },
      });
      setDashboard(payload);
    } catch (fetchError) {
      console.error(fetchError);
      if (fetchError instanceof Error && fetchError.message.includes('Sign in')) handleLogout();
      else setError('The dashboard could not load KPI metrics.');
    } finally {
      if (showLoading) setDashboardLoading(false);
    }
  };

  const handleLogin = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!category || !persona || !username.trim() || !password) {
      setError('Complete all four fields to continue.');
      return;
    }
    setIsLoading(true);
    setError('');

    try {
      const authUser = await apiFetch<User>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email: username.trim(), password, persona_id: persona }),
      });

      const selectedDesignation = PERSONAS.find((item) => item.value === persona)?.label;
      const nextUser = {
        ...authUser,
        email: authUser.email ?? username.trim(),
        designation: authUser.designation ?? selectedDesignation ?? persona,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(nextUser));
      setUser(nextUser);
    } catch (loginError) {
      setError(loginError instanceof Error ? loginError.message : 'Login failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem(STORAGE_KEY);
    setUser(null);
    setDashboard(null);
    setCategory('');
    setPersona('');
    setUsername('');
    setPassword('');
    setShowPassword(false);
    setError('');
  };

  const visibleDashboard = useMemo(() => dashboard ?? null, [dashboard]);

  if (!user) {
    return (
      <div className="auth-shell">
        <header className="auth-header">
          <div className="identity-mark" aria-hidden="true">J&amp;J</div>
          <div className="identity-copy">
            <strong>J&amp;J KPI Dashboard</strong>
            <span>Business Performance &amp; Insights</span>
          </div>
          <span className="environment-badge">DEMO</span>
        </header>

        <main className="auth-main">
          <section className="auth-card" aria-labelledby="login-title">
            <div className="form-kicker">Secure workspace access</div>
            <h1 id="login-title">Welcome back</h1>
            <p className="auth-description">Sign in to access your role-specific dashboard.</p>

            <form onSubmit={handleLogin} className="auth-form" noValidate>
              <label>
                Category
                <select value={category} onChange={(event) => setCategory(event.target.value)} required>
                  <option value="" disabled>Select category</option>
                  {CATEGORIES.map((item) => <option key={item} value={item}>{item}</option>)}
                </select>
              </label>

              <label>
                Persona
                <select value={persona} onChange={(event) => setPersona(event.target.value)} required>
                  <option value="" disabled>Select your persona</option>
                  {PERSONAS.map((item) => (
                    <option key={item.value} value={item.value} disabled={!item.defined}>
                      {item.label}
                    </option>
                  ))}
                </select>
                <small className="field-note">Your account must be assigned to the selected designation.</small>
              </label>

              <label>
                Username
                <input
                  type="text"
                  value={username}
                  onChange={(event) => setUsername(event.target.value)}
                  placeholder="Enter your username"
                  autoComplete="username"
                  required
                />
              </label>

              <label>
                Password
                <span className="password-field">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    placeholder="Enter your password"
                    autoComplete="current-password"
                    required
                  />
                  <button
                    className="password-toggle"
                    type="button"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    aria-pressed={showPassword}
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? 'Hide' : 'Show'}
                  </button>
                </span>
              </label>

              {error && <div className="error-banner" role="alert">{error}</div>}
              <button className="sign-in-button" type="submit" disabled={isLoading}>
                {isLoading ? <><span className="button-spinner" aria-hidden="true" />Signing in</> : <>Sign in <span aria-hidden="true">→</span></>}
              </button>
            </form>

            <p className="selection-note">The demo accounts are assigned to Operations Manager and Sales Rep. Other designations need an assigned account.</p>
          </section>
          <footer className="auth-footer">DEMO ENVIRONMENT <span aria-hidden="true">·</span> Not configured for corporate identity sign-in</footer>
        </main>
      </div>
    );
  }

  const statusItems = visibleDashboard?.status_panel?.items ?? [];
  const metricItems = visibleDashboard?.metric_panel?.items ?? [];
  const responsibilities = visibleDashboard?.responsibility_panel?.items ?? [];
  const actions = visibleDashboard?.action_panel?.items ?? [];
  const workflowSteps = visibleDashboard?.workflow_panel?.items ?? [];
  const kpis = visibleDashboard?.kpis ?? [];
  const processExecutions = visibleDashboard?.process_executions ?? [];
  const alerts = visibleDashboard?.alerts ?? [];
  const filteredExecutions = processExecutions.filter((execution) =>
    `${execution.customer_request_id} ${execution.process_name} ${execution.task_name} ${execution.status}`
      .toLowerCase()
      .includes(processSearch.trim().toLowerCase()),
  );
  const executionsByRequest = new Map<string, ProcessExecution[]>();
  for (const execution of processExecutions) {
    const requestExecutions = executionsByRequest.get(execution.customer_request_id) ?? [];
    requestExecutions.push(execution);
    executionsByRequest.set(execution.customer_request_id, requestExecutions);
  }
  const viewTitles: Record<DashboardView, string> = {
    overview: 'overview',
    metrics: 'customer metrics',
    alerts: 'alerts',
    workflows: 'workflows',
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-header">
          <div className="brand-mark small">J&amp;J</div>
          <div>
            <strong>Business Services</strong>
            <span>KPI Command Center</span>
          </div>
        </div>

        <nav className="nav">
          {(['overview', 'metrics', 'alerts', 'workflows'] as const).map((view) => (
            <button
              key={view}
              className={`nav-item${activeView === view ? ' active' : ''}`}
              type="button"
              aria-current={activeView === view ? 'page' : undefined}
              onClick={() => setActiveView(view)}
            >
              {view === 'metrics' ? 'Customer Metrics' : view[0].toUpperCase() + view.slice(1)}
            </button>
          ))}
        </nav>

        <div className="profile-card">
          <div className="avatar">{(visibleDashboard?.viewer.name ?? user.name).charAt(0).toUpperCase()}</div>
          <div>
            <strong>{visibleDashboard?.viewer.name ?? user.name}</strong>
            <span>{user.designation ?? user.role ?? 'Team member'}</span>
            <span>{visibleDashboard?.viewer.email ?? user.email}</span>
          </div>
        </div>
      </aside>

      <main className="content-panel">
        <header className="topbar">
          <div>
            <p className="eyebrow">Operational dashboard</p>
            <h2>{visibleDashboard?.viewer.name ? `${visibleDashboard.viewer.name}'s ${viewTitles[activeView]}` : 'Performance overview'}</h2>
          </div>
          <div className="topbar-actions">
            <div className="live-status"><span className="live-dot" />{visibleDashboard?.data_source ?? 'DEMO / SYNTHETIC DATA'} <small>{visibleDashboard?.updated_at ? new Date(visibleDashboard.updated_at).toLocaleTimeString() : ''}</small></div>
            <button className="secondary-btn" onClick={handleLogout}>Sign out</button>
          </div>
        </header>

        {error && <div className="error-banner inline">{error}</div>}

        {dashboardLoading ? (
          <div className="loading-panel">Loading KPI data…</div>
        ) : (
          <>
            {activeView === 'overview' && <>
            <section className="status-grid">
              {statusItems.length ? (
                statusItems.map((item) => (
                  <article key={item.label} className="mini-card">
                    <span>{item.label}</span>
                    <strong>{item.value}</strong>
                  </article>
                ))
              ) : (
                <div className="empty-state">No status data available for this persona.</div>
              )}
            </section>

            <section className="trend-section">
              <div className="section-heading">
                <div><p className="eyebrow">Synthetic weekly measurements</p><h3>KPI trends</h3></div>
                <span>Illustrative demo values, not production results</span>
              </div>
              <div className="trend-grid">
                {kpis.map((kpi) => (
                  <article className="trend-card" key={kpi.id}>
                    <div className="trend-card-heading"><span>{kpi.name}</span><small>{kpi.period ?? 'LIVE'}</small></div>
                    <div className="trend-card-value">{kpi.unit === 'USD' ? '$' : ''}{kpi.value.toLocaleString(undefined, { maximumFractionDigits: 2 })}<span>{kpi.unit === 'USD' ? '' : ` ${kpi.unit ?? ''}`}</span></div>
                    <TrendChart kpi={kpi} />
                  </article>
                ))}
              </div>
            </section>

            <section className="panel-grid">
              <article className="panel-card wide-panel">
                <div className="panel-heading">
                  <h3>{visibleDashboard?.metric_panel?.title ?? 'KPI metrics'}</h3>
                </div>
                <div className="metric-grid">
                  {metricItems.length ? (
                    metricItems.map((item) => (
                      <div key={item.label} className="metric-card">
                        <span>{item.label}</span>
                        <strong>
                          {typeof item.value === 'number' ? item.value.toLocaleString() : item.value}
                          {item.unit ? ` ${item.unit}` : ''}
                        </strong>
                        {item.status && <small>{item.status}</small>}
                      </div>
                    ))
                  ) : (
                    <div className="empty-state">No KPI metrics available.</div>
                  )}
                </div>
              </article>

              <article className="panel-card">
                <div className="panel-heading">
                  <h3>{visibleDashboard?.responsibility_panel?.title ?? 'Responsibilities'}</h3>
                </div>
                <div className="stack-list">
                  {responsibilities.length ? (
                    responsibilities.map((item) => (
                      <div key={item.title} className="list-item">
                        <div>
                          <strong>{item.title}</strong>
                          <small>{item.owner}</small>
                        </div>
                        <span>{item.due}</span>
                        <em>{item.status}</em>
                      </div>
                    ))
                  ) : (
                    <div className="empty-state">No responsibilities configured.</div>
                  )}
                </div>
              </article>

              <article className="panel-card">
                <div className="panel-heading">
                  <h3>{visibleDashboard?.action_panel?.title ?? 'Actions'}</h3>
                </div>
                <div className="stack-list">
                  {actions.length ? (
                    actions.map((item) => (
                      <div key={item.title} className="list-item">
                        <div>
                          <strong>{item.title}</strong>
                          <small>{item.kpi}</small>
                        </div>
                        <em>{item.priority}</em>
                      </div>
                    ))
                  ) : (
                    <div className="empty-state">No pending actions.</div>
                  )}
                </div>
              </article>

              <article className="panel-card">
                <div className="panel-heading">
                  <h3>{visibleDashboard?.workflow_panel?.title ?? 'Workflow'}</h3>
                </div>
                <div className="timeline">
                  {workflowSteps.length ? (
                    workflowSteps.map((step) => (
                      <div key={step.step} className="timeline-step">
                        <span className="dot" />
                        <div>
                          <strong>{step.step}</strong>
                          <small>{step.status}</small>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="empty-state">No workflow steps available.</div>
                  )}
                </div>
              </article>
            </section>
            </>}

            {activeView === 'metrics' && <section className="panel-card details-panel">
              <div className="panel-heading">
                <h3>{visibleDashboard?.metric_panel?.title ?? 'Customer metrics'}</h3>
              </div>
              <div className="kpi-list">
                {kpis.length ? (
                  kpis.map((kpi) => (
                    <article key={kpi.id} className="kpi-card">
                      <div className="kpi-header">
                        <div>
                          <h4>{kpi.name}</h4>
                          <p>{kpi.description ?? 'No description provided.'}</p>
                        </div>
                        <span className="status-pill demo">{kpi.status ?? 'DEMO / illustrative'}</span>
                      </div>
                      <div className="kpi-row">
                        <strong>{kpi.value}</strong>
                        <span>{kpi.unit ?? '%'}</span>
                      </div>
                      <div className="kpi-meta">
                        <span>Target: {kpi.target ?? 'Not supplied'}</span>
                        <span>Period: {kpi.period ?? 'N/A'}</span>
                        <span>Sample size: {kpi.sample_size ?? 'Derived from executions'}</span>
                        <span>Source: {kpi.source ?? 'Process execution ledger'}</span>
                      </div>
                    </article>
                  ))
                ) : (
                  <div className="empty-state">No KPI definitions available for this persona.</div>
                )}
              </div>
            </section>}

            {activeView === 'workflows' && <>
            <section className="panel-card details-panel">
              <div className="panel-heading">
                <div>
                  <h3>Request workflow history</h3>
                  <p>Process executions grouped by synthetic customer request and ordered by configured sequence.</p>
                </div>
              </div>
              <div className="workflow-history">
                {[...executionsByRequest.entries()].map(([requestId, executions]) => (
                  <article key={requestId} className="workflow-request">
                    <h4>{requestId}</h4>
                    <ol>
                      {[...executions].sort((left, right) => left.process_sequence - right.process_sequence).map((execution) => (
                        <li key={execution.process_execution_id}>
                          <span className={`workflow-state ${execution.status.toLowerCase().replace(/\s+/g, '-')}`} />
                          <div>
                            <strong>{execution.process_name}</strong>
                            <small>{execution.status} · {execution.duration_minutes === null ? `${execution.elapsed_minutes ?? 0} min elapsed` : `${execution.duration_minutes} min`}</small>
                            {execution.retry_count > 0 && <small>Retry {execution.retry_count}</small>}
                          </div>
                        </li>
                      ))}
                    </ol>
                  </article>
                ))}
                {!executionsByRequest.size && <div className="empty-state">No workflow executions are assigned to this account.</div>}
              </div>
            </section>

            <section className="panel-card details-panel">
              <div className="panel-heading execution-heading">
                <div>
                  <h3>My process execution history</h3>
                  <p>Completed duration excludes unfinished work; active work shows elapsed time.</p>
                </div>
                <label className="execution-search">
                  Search
                  <input value={processSearch} onChange={(event) => setProcessSearch(event.target.value)} placeholder="Request, process, task, status" />
                </label>
              </div>
              <div className="table-scroll">
                <table className="execution-table">
                  <thead>
                    <tr><th>Request</th><th>Process / task</th><th>Status</th><th>Duration</th><th>SLA</th><th>Alert</th></tr>
                  </thead>
                  <tbody>
                    {filteredExecutions.map((execution) => {
                      const observedMinutes = execution.duration_minutes ?? execution.elapsed_minutes ?? 0;
                      const breached = observedMinutes > execution.sla_target_minutes;
                      return (
                        <tr key={execution.process_execution_id}>
                          <td>{execution.customer_request_id}</td>
                          <td>
                            <details>
                              <summary>{execution.process_name}</summary>
                              <small>{execution.task_name} · {execution.process_execution_id}</small>
                              {execution.retry_count > 0 && <small>Retry count: {execution.retry_count}</small>}
                              {execution.failure_reason && <small>{execution.failure_reason}</small>}
                            </details>
                          </td>
                          <td>{execution.status}</td>
                          <td>{execution.duration_minutes === null ? `${execution.elapsed_minutes ?? 0} min elapsed` : `${execution.duration_minutes} min`}</td>
                          <td>{breached ? 'Over SLA' : 'Within SLA'} · {execution.sla_target_minutes} min</td>
                          <td>{execution.alert_id ?? 'None'}</td>
                        </tr>
                      );
                    })}
                    {!filteredExecutions.length && <tr><td colSpan={6}>No process executions match this search.</td></tr>}
                  </tbody>
                </table>
              </div>
            </section>
            </>}

            {activeView === 'alerts' && <section className="panel-card details-panel">
              <div className="panel-heading"><h3>My alerts</h3></div>
              {alerts.length ? (
                <div className="table-scroll">
                  <table className="execution-table">
                    <thead><tr><th>Alert type</th><th>Severity</th><th>Request / process execution</th><th>Observed</th><th>Threshold</th><th>Status</th><th>Reason</th></tr></thead>
                    <tbody>
                      {alerts.map((alert) => (
                        <tr key={alert.alert_id}>
                          <td>{alert.alert_type}<small>{alert.alert_id}</small></td>
                          <td>{alert.severity}</td>
                          <td>{alert.customer_request_id}<small>{alert.process_execution_id}</small></td>
                          <td>{alert.observed_minutes} min</td>
                          <td>{alert.threshold_minutes} min</td>
                          <td>{alert.resolution_status}</td>
                          <td>{alert.reason}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : <div className="empty-state">No alerts for this account.</div>}
            </section>}
          </>
        )}
      </main>
    </div>
  );
}
