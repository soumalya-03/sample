from backend.app.services.demo_dashboard_service import build_individual_dashboard_payload


def build_dashboard(email: str, name: str, persona_id: str) -> dict:
    return build_individual_dashboard_payload(
        email,
        {"name": name, "email": email},
        persona_id,
    )


def test_demo_dashboard_is_scoped_to_authenticated_resource():
    operations = build_dashboard("admin@local.dev", "Local Admin", "role-09")
    sales = build_dashboard("sales@local.dev", "Jordan Lee", "role-14")

    assert len(operations["requests"]) == 6
    assert len(sales["requests"]) == 6
    assert {item["resource_id"] for item in operations["process_executions"]} == {"RES-OPS-001"}
    assert {item["resource_id"] for item in sales["process_executions"]} == {"RES-SALES-001"}
    assert operations["kpis"][0]["name"] == "Overall SLA Achievement"
    assert sales["kpis"][0]["name"] == "Account Review Completion"


def test_demo_dashboard_calculates_measurements_and_excludes_open_duration():
    payload = build_dashboard("admin@local.dev", "Local Admin", "role-09")
    sla_kpi = next(item for item in payload["kpis"] if item["name"] == "Overall SLA Achievement")
    open_execution = next(item for item in payload["process_executions"] if item["status"] == "In Progress")

    assert sla_kpi["value"] == 93.0
    assert sla_kpi["status"] == "DEMO / illustrative"
    assert open_execution["duration_minutes"] is None
    assert open_execution["elapsed_minutes"] > 0


def test_failed_attempt_retry_and_sla_alerts_remain_traceable():
    payload = build_dashboard("admin@local.dev", "Local Admin", "role-09")
    failed = next(item for item in payload["process_executions"] if item["outcome"] == "Failed")
    retry = next(
        item for item in payload["process_executions"]
        if item["customer_request_id"] == failed["customer_request_id"]
        and item["process_id"] == failed["process_id"]
        and item["retry_count"] == 1
    )
    execution_ids = {item["process_execution_id"] for item in payload["process_executions"]}

    assert failed["process_execution_id"] != retry["process_execution_id"]
    assert retry["outcome"] == "Completed"
    assert all(alert["process_execution_id"] in execution_ids for alert in payload["alerts"])
